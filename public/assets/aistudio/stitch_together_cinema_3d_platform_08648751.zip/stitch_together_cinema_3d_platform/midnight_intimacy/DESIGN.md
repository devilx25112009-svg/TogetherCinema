---
name: Midnight Intimacy
colors:
  surface: '#13131b'
  surface-dim: '#13131b'
  surface-bright: '#393842'
  surface-container-lowest: '#0d0d16'
  surface-container-low: '#1b1b23'
  surface-container: '#1f1f28'
  surface-container-high: '#292932'
  surface-container-highest: '#34343d'
  on-surface: '#e4e1ed'
  on-surface-variant: '#cbc3d7'
  inverse-surface: '#e4e1ed'
  inverse-on-surface: '#302f39'
  outline: '#948ea0'
  outline-variant: '#494454'
  surface-tint: '#cfbdff'
  primary: '#cfbdff'
  on-primary: '#3a0093'
  primary-container: '#9d79ff'
  on-primary-container: '#320082'
  inverse-primary: '#6a3dd6'
  secondary: '#ffafd3'
  on-secondary: '#620040'
  secondary-container: '#85145a'
  on-secondary-container: '#ff93c8'
  tertiary: '#afc6ff'
  on-tertiary: '#002d6d'
  tertiary-container: '#698fe3'
  on-tertiary-container: '#002760'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#e8ddff'
  primary-fixed-dim: '#cfbdff'
  on-primary-fixed: '#22005d'
  on-primary-fixed-variant: '#521abe'
  secondary-fixed: '#ffd8e7'
  secondary-fixed-dim: '#ffafd3'
  on-secondary-fixed: '#3d0026'
  on-secondary-fixed-variant: '#85145a'
  tertiary-fixed: '#d9e2ff'
  tertiary-fixed-dim: '#afc6ff'
  on-tertiary-fixed: '#001944'
  on-tertiary-fixed-variant: '#104393'
  background: '#13131b'
  on-background: '#e4e1ed'
  surface-variant: '#34343d'
typography:
  display-hero:
    fontFamily: Space Grotesk
    fontSize: 56px
    fontWeight: '700'
    lineHeight: 64px
    letterSpacing: -0.03em
  display-hero-mobile:
    fontFamily: Space Grotesk
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 44px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Space Grotesk
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Space Grotesk
    fontSize: 26px
    fontWeight: '600'
    lineHeight: 34px
    letterSpacing: -0.015em
  headline-md:
    fontFamily: Space Grotesk
    fontSize: 24px
    fontWeight: '500'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Space Grotesk
    fontSize: 20px
    fontWeight: '500'
    lineHeight: 28px
  title-md:
    fontFamily: Space Grotesk
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
    letterSpacing: 0.01em
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 26px
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 22px
  body-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 18px
  label-lg:
    fontFamily: Space Grotesk
    fontSize: 13px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.04em
  label-md:
    fontFamily: Space Grotesk
    fontSize: 11px
    fontWeight: '500'
    lineHeight: 14px
    letterSpacing: 0.06em
  label-sm:
    fontFamily: Space Grotesk
    fontSize: 10px
    fontWeight: '500'
    lineHeight: 12px
    letterSpacing: 0.08em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-mobile: 1rem
  margin: 2.5rem
  margin-mobile: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

This design system translates the intimate grandeur of an exclusive, midnight-lit screening room into an interactive digital space. Engineered specifically for couples navigating geographic distance, the interface simulates the presence of being seated together in a private, high-fidelity projection theatre.

### Personality & Emotional Tenor
- **Atmospheric & Private:** Evokes the feeling of entering a soundproofed, velvet-clad private cinema hall at 1:00 AM with the person you love.
- **Cinematic Precision:** Ultra-high dynamic range visuals, tactile glass reflections, and responsive projection glows replace standard interface chrome.
- **Romantic Technological Elevation:** Cutting-edge synchronized playback wrapped in warm, tender accents—softening cold telemetry with emotional cues like heartbeat haptics, shared whispered voice memos, and ambient room cast reflections.

### Design Movement: Atmospheric Glassmorphism & Nocturnal Skeuomorphism
The interface blends deep layered glassmorphism with subtle physical cues reminiscent of acoustic theatre fabrics, brushed anodized aerospace controls, and anamorphic lens light falloff. Background surfaces do not rely on flat greys; they use deep spectral midnight ink tones layered beneath volumetric lighting cones that dynamically absorb the running film's dominant hues.

## Colors

The palette is tuned entirely for low-light environments, maximizing screen contrast while shielding the viewers' eyes from retinal fatigue during extended screening sessions.

### Functional Roles & Application Rules
- **Primary (`#9167FF` - Electric Purple):** The primary kinetic driver. Used for active video transport states, playback scrubber thumbs, spatial audio focus toggles, and high-priority call-to-actions.
- **Secondary (`#F472B6` - Rose Pink):** The emotional layer. Reserved for relational markers: reaction bursts, shared synchronized bookmarks, "holding hands" touchpoint gestures, and partner presence indicators.
- **Tertiary (`#83A9FF` - Soft Blue):** Informational atmospheric depth. Represents spatial audio channel visualization, peripheral telemetry, and remote room ambiance.
- **Neutral Canvas (`#080810` - Midnight Black):** The infinite baseline darkness that allows video projections and volumetric backlights to bloom organically.

### Supporting Accent & Surface Shades
- **Midnight Velvet (`#0B1020` to `#171126`):** Gradient bases for large application surfaces, replicating dark acoustic felt paneling.
- **Dark Surface Elevated (`#201B2E`):** Distinct elevated surface tier for overlays, side drawers, and floating synchronized remote controls.
- **Lavender Soft Tint (`#C4B5FD`):** High-readability tertiary text and dimmed secondary indicators.

## Typography

Typography balances futuristic precision with optical clarity in the dark.

- **Headlines & Interface Labels (Space Grotesk):** Provides the technical architectural scaffolding of high-grade audio/video equipment while retaining warmth through distinctive ink-traps and geometric forms.
- **Running Body & Dialogue Captions (Inter):** Deployed for descriptions, synchronized subtitles, partner chat, and settings due to its neutral rendering and tall x-height in low ambient light.
- **Letter Spacing:** All uppercase micro-labels and counter timers receive tracked letter spacing (`+0.04em` to `+0.08em`) to guarantee legibility over dark moving film projections.

## Layout & Spacing

The canvas is constructed around a distraction-free, fluid presentation model that adjusts seamlessly between passive cinematic immersion and active social coordination.

### Layout Model
- **12-Column Responsive Grid:** Fluid grid system for theatre lobbies, curated film vaults, and seat management views.
- **Canvas Breakpoints:**
  - **Mobile (< 768px):** Single-column stacked mode with persistent bottom-pinned partner audio controls and collapsible half-sheet chat. Margins clamp to `1rem`.
  - **Tablet (768px - 1199px):** Split-view 8/4 proportion during playback, allocating 8 columns to the screen canvas and 4 columns to the bilateral partner viewport.
  - **Desktop / Ultra-Wide (>= 1200px):** 12-column widescreen framing with `2.5rem` outer margins. Content stays centered within a maximum container width of `1600px` to avoid stretching visual focus during movie playback.

### Spacing Philosophy
Spacing tokens govern empty airspace exclusively. Compact spacing (`space-xs`, `space-sm`) clusters interdependent playback controls (e.g., play/pause alongside audio levels), while expansive tokens (`space-lg`, `space-xl`) isolate the cinematic frame from interpersonal communication tools to prevent visual clutter.

## Elevation & Depth

Visual hierarchy is built with volumetric light projection, luminous rim reflections, and semi-transparent dark glass layers rather than drop shadows.

### Atmospheric Glass Surfaces
- **Level 0 (Floor/Backdrop):** Raw `#080810` canvas with radial volumetric gradient blooms (`rgba(109, 66, 200, 0.12)` into `rgba(131, 169, 255, 0.08)`).
- **Level 1 (Dock & Shelves):** Dark acrylic glass (`#201B2E` at 65% opacity), backed by `backdrop-filter: blur(24px)` and enclosed by a subtle 1px inner rim border (`rgba(255, 255, 255, 0.08)`).
- **Level 2 (Floating Remotes & Dialogs):** `#171126` at 85% opacity with `backdrop-filter: blur(36px)` accompanied by an ambient purple-tinted halo: `0 16px 40px -8px rgba(145, 103, 255, 0.25)`.
- **Level 3 (Direct Partner Touchpoint):** Rose-lit active elements gain an emotional perimeter glow: `0 0 24px rgba(244, 114, 182, 0.35)`.

## Shapes

The geometric framework balances precision optics with friendly, tactile comfort.

- **Base Radius (0.5rem / 8px):** Applied to interactive buttons, text inputs, micro-badges, and timeline scrub indicators.
- **Container Radius (1rem / 16px):** Standard for content cards, partner video camera tiles, chat bubbles, and modal frames.
- **Theatre Display Radius (1.5rem / 24px):** Reserved for the outer 3D virtual cinema display window and full-screen ambient projection shrouds.
- **Pill Profiles:** Strictly reserved for status toggles (e.g., "In Sync" badges, microphone muting capsules, and live timecode chips).

## Components

### Buttons & Transport Controls
- **Primary Playback Actions:** Rounded-md capsules styled in Electric Purple (`#9167FF`) with stark White icons, applying a gentle luminescence (`box-shadow: 0 0 16px rgba(145, 103, 255, 0.4)`) on hover.
- **Intimacy Actions (Send Heartbeat, Nudge Partner):** Pill containers filled with translucent Rose Pink (`rgba(244, 114, 182, 0.15)`) and bordered with `1px solid rgba(244, 114, 182, 0.4)`. Transitions to solid `#F472B6` with haptic feedback upon engagement.
- **Glass Utility Buttons:** Translucent dark surface with an ultra-thin 1px border (`rgba(255, 255, 255, 0.1)`), brightening smoothly on hover.

### Dynamic Player HUD & Timeline Scrubbing
- **Synchronized Scrubber:** Dual-thumb progress bar indicating local and partner buffer states. Electric Purple track showing shared playback, punctuated by Rose Pink markers where either partner marked a favorite scene.
- **Hover Previews:** Framed in frosted glass (`#201B2E`, 80% opacity) with the frame timecode set in Space Grotesk `label-md`.

### Cards (Cinematic Catalog & Screening Sessions)
- **Ratio & Treatment:** 16:9 widescreen and 2:3 key-art orientations with 16px corner rounding. Dark velvet background with lazy-loaded imagery.
- **Focus State:** Subtle scale transition (`scale(1.02)`) paired with a dynamic ambient underglow derived from the dominant poster color.

### Presence & Reaction Chips
- **Partner Synchronicity Indicator:** Pill badge displaying "0.00s DELAY" with an oscillating green/electric purple ping indicator dot.
- **Whisper Memo & Reaction Pills:** Compact floating overlays over video edges that fade away within 4 seconds of idle activity.

### Inputs & Selection Controls
- **Text Inputs (Lobby & Real-Time Note Sharing):** `#0B1020` base with `1px solid rgba(196, 181, 253, 0.2)` border, expanding to an Electric Purple rim with faint purple aura on focus.
- **Checkboxes & Toggles:** Smooth toggle pills that slide with a spring easing curve; active state lights up in `#9167FF` with a white indicator core.